# RESTHeart Core

This module provides RESTHeart's fundamental capabilities: An HTTP server via Undertow and a bootstrapper able to read the configuration and start the main process.

<hr />

_Made with :heart: by [SoftInstigate](http://www.softinstigate.com/). Follow us on [Twitter](https://twitter.com/softinstigate)_.
